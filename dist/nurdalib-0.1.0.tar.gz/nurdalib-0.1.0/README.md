**Description**
This library was created for Data Engineering Homework 1 (MG-GY 8411) by Professor De Oliveira 
at the NYU Tandon School of Engineering. This library contains the main() function with the API key 
for Polygon from the code of Max Maximilian, a former student at NYU Tandon.

**Installation**
pip install nurdalib