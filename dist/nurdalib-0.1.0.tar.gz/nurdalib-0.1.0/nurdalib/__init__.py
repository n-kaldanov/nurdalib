# This line of code allows us to import main() function into Max's code with shorter and prettier code
from nurdalib.main import main
